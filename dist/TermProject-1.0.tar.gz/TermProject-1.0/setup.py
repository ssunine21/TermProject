from distutils.core import setup

setup(name='TermProject',
      version='1.0',
      py_modules=['TermProject'] #파일이나 폴더 이름을지정할 수 있다. 폴더 이름을 지정하는 것이 쉽다.
      )
